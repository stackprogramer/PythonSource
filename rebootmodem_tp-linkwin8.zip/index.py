import sys
import telnetlib
import time


HOST = "192.168.1.1"
user = "admin"
password = "admin"
port = "23"
telnet = telnetlib.Telnet(HOST,port)
#telnet.read_until(b"login: ")
#telnet.write(admin.encode('ascii') + b"\n")
print("started to enter password");

telnet.read_until(b"Password: ")
telnet.write(password.encode('ascii') + b"\n")
print("connected to telnet");
telnet.read_until(b"TP-LINK>")
print("selected set");
telnet.write(b"set reboot\n")
#time.sleep(3);
print("selected reboot");
#time.sleep(3);
telnet.read_until(b"TP-LINK>")
telnet.write(b"set reboot\n")
print("modem is rebooting");
